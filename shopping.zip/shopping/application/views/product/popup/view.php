<div class="modal fade product_view" id="quick-view-product">
    <div class="modal-dialog">
        <div class="modal-content" id="render-quick-product">
            <div class="text-center"><i class="fa fa-spinner fa-pulse fa-5x fa-fw"></i></div>
        </div>
    </div>
</div>